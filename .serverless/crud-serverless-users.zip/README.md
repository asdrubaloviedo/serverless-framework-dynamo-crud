## Tabla de Contenidos

1. [Instalación](#instalación)
2. [Levantamiento](#levantamiento)
3. [Contenido](#contenido)
4. [Autores](#autores)

## Instalación

```bash
npm install
```

## Levantamiento

1.- Ambiente de desarrollo

```bash
serverless deploy
```

## Contenido

serverless, serverless framework, serverless-offline, lambda, api-gateway

## Autores

Asdrúbal Oviedo
